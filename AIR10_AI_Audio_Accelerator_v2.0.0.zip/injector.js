/**
 * AIR10 AI Audio Accelerator (Universal Edition for Gemini & ChatGPT)
 * Designed by ANTIGRAVITY for Rajon
 * 
 * Target Domains:
 * - https://gemini.google.com/*
 * - https://chatgpt.com/*
 * 
 * Architecture:
 * 1. Web Audio API Hook (AudioBufferSourceNode) -> Gemini streaming chunk engine
 * 2. HTMLAudioElement Prototype & Watchdog -> ChatGPT Read Aloud reusable/dynamic audio element
 * 3. Event-Driven Capture & MutationObserver -> Zero dependency on fragile DOM selectors
 * 4. Zero Live Voice Interference -> Strictly targets Read Aloud playback
 * 5. 5-Gear Speed Ladder: [1.5x, 1.75x, 2.0x (Default), 2.5x, 3.0x]
 * 6. Option+S (Alt+S) Global Shortcut with typing protection
 * 7. Real-Time Active Audio Shift without restart
 * 8. Persistent Speed Preference via localStorage
 */
(() => {
  'use strict';

  if (window.__AIR10_AUDIO_ACCELERATOR__) return;
  window.__AIR10_AUDIO_ACCELERATOR__ = true;

  const SPEEDS = [1.5, 1.75, 2.0, 2.5, 3.0];
  
  // Load saved speed from localStorage or default to 2.0x
  let savedSpeed = 2.0;
  try {
    const val = parseFloat(localStorage.getItem('air10_ai_speed'));
    if (!isNaN(val) && SPEEDS.includes(val)) {
      savedSpeed = val;
    }
  } catch (e) {}

  let currentIndex = SPEEDS.indexOf(savedSpeed) !== -1 ? SPEEDS.indexOf(savedSpeed) : 2;
  let targetSpeed = SPEEDS[currentIndex];

  const activeMediaElements = new Set();
  const activeBufferSources = new Set();

  // Helper to enforce speed on an audio element
  function enforceAudioSpeed(media) {
    if (!media) return;
    const isAudio = media instanceof HTMLAudioElement || media.tagName === 'AUDIO';
    if (!isAudio) return;

    try {
      media.defaultPlaybackRate = targetSpeed;
      if (Math.abs(media.playbackRate - targetSpeed) > 0.01) {
        media.playbackRate = targetSpeed;
      }
      if ('preservesPitch' in media) {
        media.preservesPitch = true;
      }
    } catch (e) {}
  }

  // =========================================================================
  // 1. Web Audio API Interception (Gemini Primary Stream Engine)
  // =========================================================================
  if (typeof AudioBufferSourceNode !== 'undefined') {
    const origBufferStart = AudioBufferSourceNode.prototype.start;
    AudioBufferSourceNode.prototype.start = function(...args) {
      try {
        if (this.playbackRate && typeof this.playbackRate.value === 'number') {
          this.playbackRate.value = targetSpeed;
        }
        activeBufferSources.add(this);
        this.addEventListener('ended', () => activeBufferSources.delete(this), { once: true });
        console.log(`%c[AIR10 WebAudio]%c AudioBufferSourceNode locked to ${targetSpeed}x on ${location.hostname}`, 'color:#6366f1;font-weight:bold;', 'color:#10b981;font-weight:bold;');
      } catch (err) {}
      return origBufferStart.apply(this, args);
    };

    if (typeof AudioParam !== 'undefined' && AudioParam.prototype.setValueAtTime) {
      const origSetValueAtTime = AudioParam.prototype.setValueAtTime;
      AudioParam.prototype.setValueAtTime = function(value, startTime) {
        let finalValue = value;
        if (this.__isPlaybackRateParam || (value === 1.0 && targetSpeed !== 1.0)) {
          finalValue = targetSpeed;
        }
        return origSetValueAtTime.call(this, finalValue, startTime);
      };
    }
  }

  if (typeof BaseAudioContext !== 'undefined' && BaseAudioContext.prototype.createBufferSource) {
    const origCreateBufferSource = BaseAudioContext.prototype.createBufferSource;
    BaseAudioContext.prototype.createBufferSource = function(...args) {
      const source = origCreateBufferSource.apply(this, args);
      try {
        if (source && source.playbackRate) {
          source.playbackRate.__isPlaybackRateParam = true;
          source.playbackRate.value = targetSpeed;
        }
      } catch (e) {}
      return source;
    };
  }

  // =========================================================================
  // 2. HTMLMediaElement Prototype Hook (ChatGPT & Fallback Audio)
  // =========================================================================
  const nativePlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function(...args) {
    const isAudio = this instanceof HTMLAudioElement || this.tagName === 'AUDIO';
    if (isAudio) {
      enforceAudioSpeed(this);
      activeMediaElements.add(this);

      // Microtask + timed safety checks (guards against ChatGPT internal reset after play())
      queueMicrotask(() => enforceAudioSpeed(this));
      setTimeout(() => enforceAudioSpeed(this), 50);
      setTimeout(() => enforceAudioSpeed(this), 250);

      this.addEventListener('ended', () => activeMediaElements.delete(this), { once: true });
      this.addEventListener('pause', () => activeMediaElements.delete(this));

      console.log(`%c[AIR10 HTMLAudio]%c Audio element play intercepted at ${targetSpeed}x on ${location.hostname}`, 'color:#6366f1;font-weight:bold;', 'color:#10b981;font-weight:bold;');
    }
    return nativePlay.apply(this, args);
  };

  // Capture phase listeners for all media events
  ['play', 'playing', 'loadedmetadata', 'canplay'].forEach(eventType => {
    document.addEventListener(eventType, (e) => {
      enforceAudioSpeed(e.target);
    }, true);
  });

  // Ratechange watchdog: If website attempts to reset speed back to 1.0x
  document.addEventListener('ratechange', (e) => {
    const el = e.target;
    if (el && (el instanceof HTMLAudioElement || el.tagName === 'AUDIO')) {
      if (Math.abs(el.playbackRate - targetSpeed) > 0.01) {
        queueMicrotask(() => enforceAudioSpeed(el));
      }
    }
  }, true);

  // MutationObserver fallback: Detect newly attached <audio> elements in DOM
  const domObserver = new MutationObserver(() => {
    document.querySelectorAll('audio').forEach(enforceAudioSpeed);
  });
  if (document.documentElement) {
    domObserver.observe(document.documentElement, { childList: true, subtree: true });
  }
  document.querySelectorAll('audio').forEach(enforceAudioSpeed);

  // =========================================================================
  // 3. Web Speech API Hook (Fallback Voice)
  // =========================================================================
  if ('speechSynthesis' in window) {
    const origSpeak = window.speechSynthesis.speak;
    window.speechSynthesis.speak = function(utterance) {
      try {
        if (utterance) {
          utterance.rate = targetSpeed;
        }
      } catch (e) {}
      return origSpeak.call(this, utterance);
    };
  }

  // =========================================================================
  // 4. Central Speed Transmission Engine & Storage
  // =========================================================================
  function applySpeed(newSpeed, source = 'manual') {
    targetSpeed = newSpeed;

    // Save to localStorage so preference survives page reloads
    try {
      localStorage.setItem('air10_ai_speed', targetSpeed.toString());
    } catch (e) {}

    // A. Real-time shift active audio elements
    activeMediaElements.forEach(enforceAudioSpeed);
    document.querySelectorAll('audio').forEach(enforceAudioSpeed);

    // B. Real-time shift active Web Audio buffer sources
    activeBufferSources.forEach(src => {
      try {
        if (src.playbackRate && typeof src.playbackRate.value === 'number') {
          src.playbackRate.value = targetSpeed;
        }
      } catch (e) {}
    });

    // C. Update on-screen visual badge
    const label = document.getElementById('speed-label');
    if (label) {
      label.innerText = `${parseFloat(targetSpeed.toFixed(2))}x`;
    }
    const badge = document.getElementById('air10-speed-pill');
    if (badge) {
      badge.style.borderColor = '#10b981';
      badge.style.transform = 'translateY(-2px) scale(1.05)';
      setTimeout(() => {
        badge.style.borderColor = 'rgba(99, 102, 241, 0.45)';
        badge.style.transform = 'translateY(0) scale(1)';
      }, 300);
    }

    console.log(`%c[AIR10]%c ⚡ Speed locked to ${targetSpeed}x (${source}) on ${location.hostname}`, 'color:#6366f1;font-weight:bold;', 'color:#10b981;font-weight:bold;');
  }

  function cycleSpeed(source = 'click') {
    currentIndex = (currentIndex + 1) % SPEEDS.length;
    applySpeed(SPEEDS[currentIndex], source);
  }

  // =========================================================================
  // 5. Global Shortcut: Option + S (Alt + S)
  // =========================================================================
  window.addEventListener('keydown', (e) => {
    const activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
    const isEditing = activeTag === 'input' || activeTag === 'textarea' || (document.activeElement && document.activeElement.isContentEditable);

    if (e.altKey && (e.code === 'KeyS' || e.key === 's' || e.key === 'S' || e.key === 'ß') && !isEditing) {
      e.preventDefault();
      e.stopPropagation();
      cycleSpeed('Option+S shortcut');
    }
  }, true);

  // =========================================================================
  // 6. Floating Status Pill Widget (Gemini & ChatGPT Compatible)
  // =========================================================================
  function mountSpeedBadge() {
    if (document.getElementById('air10-speed-pill') || document.getElementById('gemini-speed-pill')) return;
    if (!document.body) {
      setTimeout(mountSpeedBadge, 150);
      return;
    }

    const badge = document.createElement('div');
    badge.id = 'air10-speed-pill';
    badge.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;">
        <span style="font-size:12px;">🎙️</span>
        <span id="speed-label" style="font-size:12px;font-weight:700;color:#f8fafc;letter-spacing:0.02em;">${parseFloat(targetSpeed.toFixed(2))}x</span>
        <span style="font-size:9px;background:rgba(99,102,241,0.25);color:#a5b4fc;border:1px solid rgba(99,102,241,0.4);border-radius:4px;padding:1px 4px;font-weight:600;">Opt+S</span>
      </div>
    `;

    Object.assign(badge.style, {
      position: 'fixed',
      bottom: '20px',
      right: '24px',
      zIndex: '2147483647',
      padding: '6px 14px',
      background: 'rgba(15, 23, 42, 0.88)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      border: '1px solid rgba(99, 102, 241, 0.45)',
      borderRadius: '999px',
      boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
      color: '#f8fafc',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      cursor: 'pointer',
      userSelect: 'none',
      transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)'
    });

    badge.title = 'Click or press Option+S to cycle: 1.5x -> 1.75x -> 2.0x -> 2.5x -> 3.0x';
    badge.onclick = () => cycleSpeed('badge click');

    badge.onmouseenter = () => {
      badge.style.transform = 'translateY(-2px) scale(1.03)';
      badge.style.borderColor = '#818cf8';
    };
    badge.onmouseleave = () => {
      badge.style.transform = 'translateY(0) scale(1)';
      badge.style.borderColor = 'rgba(99, 102, 241, 0.45)';
    };

    document.body.appendChild(badge);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountSpeedBadge);
  } else {
    mountSpeedBadge();
  }

  console.log(`%c[AIR10 Universal Accelerator Active]%c Gemini + ChatGPT locked to ${targetSpeed}x`, 'color:#6366f1;font-weight:bold;font-size:12px;', 'color:#10b981;font-weight:bold;');
})();
